import pygame
import random

# Initialize the game
pygame.init()

# Set up the game window
window_width, window_height = 800, 600
window = pygame.display.set_mode((window_width, window_height))
pygame.display.set_caption("Snake Game")

# Define colors
white = (255, 255, 255)
black = (0, 0, 0)
green = (0, 255, 0)
red = (255, 0, 0)


# Define the snake class
class Snake:
    def __init__(self):
        self.size = 20
        self.x = window_width // 2
        self.y = window_height // 2
        self.dx = 0
        self.dy = 0
        self.body = []
        self.length = 1
        self.speed = 10  # Snake speed (higher value = faster speed)

    def draw(self):
        for segment in self.body:
            pygame.draw.rect(window, green, (segment[0], segment[1], self.size, self.size))

    def move(self):
        self.x += self.dx * self.size
        self.y += self.dy * self.size

    def check_collision(self):
        if self.x >= window_width or self.x < 0 or self.y >= window_height or self.y < 0:
            return True
        for segment in self.body[1:]:
            if self.x == segment[0] and self.y == segment[1]:
                return True
        return False

    def eat(self, food):
        if self.x == food.x and self.y == food.y:
            self.length += 1
            return True
        return False

    def update_body(self):
        self.body.append((self.x, self.y))
        if len(self.body) > self.length:
            del self.body[0]

    def reset(self):
        self.x = window_width // 2
        self.y = window_height // 2
        self.dx = 0
        self.dy = 0
        self.body = []
        self.length = 1


# Define the food class
class Food:
    def __init__(self):
        self.size = 20
        self.x = random.randint(0, (window_width - self.size) // self.size) * self.size
        self.y = random.randint(0, (window_height - self.size) // self.size) * self.size

    def draw(self):
        pygame.draw.rect(window, red, (self.x, self.y, self.size, self.size))


# Initialize the snake and food objects
snake = Snake()
food = Food()

# Game loop
running = True
clock = pygame.time.Clock()
score = 0
game_over = False
restart = False

while running:
    # Handle events
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_UP and snake.dy != 1:
                snake.dx = 0
                snake.dy = -1
            elif event.key == pygame.K_DOWN and snake.dy != -1:
                snake.dx = 0
                snake.dy = 1
            elif event.key == pygame.K_LEFT and snake.dx != 1:
                snake.dx = -1
                snake.dy = 0
            elif event.key == pygame.K_RIGHT and snake.dx != -1:
                snake.dx = 1
                snake.dy = 0
            elif event.key == pygame.K_SPACE:
                if game_over:
                    snake.reset()
                    score = 0
                    game_over = False
                    restart = False

    if not game_over:
        # Clear the screen
        window.fill(black)

        # Move the snake
        snake.move()

        # Check collision with walls or self
        if snake.check_collision():
            game_over = True
            restart = True

        # Check if snake eats the food
        if snake.eat(food):
            score += 1
            food = Food()

        # Update the snake's body
        snake.update_body()

        # Draw the snake and food
        snake.draw()
        food.draw()

        # Display the score
        font = pygame.font.Font(None, 36)
        score_text = font.render(f"Score: {score}", True, white)
        window.blit(score_text, (10, 10))
    else:
        # Display "Game Over" and restart instructions
        font = pygame.font.Font(None, 72)
        game_over_text = font.render("Game Over", True, white)
        text_rect = game_over_text.get_rect(center=(window_width // 2, window_height // 2))
        window.blit(game_over_text, text_rect)

        if restart:
            restart_text = font.render("Press SPACE to restart", True, white)
            restart_rect = restart_text.get_rect(center=(window_width // 2, window_height // 2 + 50))
            window.blit(restart_text, restart_rect)

    # Update the display
    pygame.display.update()

    # Control the game speed
    clock.tick(snake.speed)

# Quit the game
pygame.quit()
